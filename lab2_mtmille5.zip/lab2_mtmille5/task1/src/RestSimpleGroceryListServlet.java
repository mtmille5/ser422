package task1;

import javax.servlet.*;
import javax.servlet.http.*;

import java.io.*;

import java.util.Vector;
import java.net.URLDecoder;

import java.util.concurrent.CopyOnWriteArraySet;
import java.util.Hashtable;

import javax.json.*;

@SuppressWarnings("serial")
public class RestSimpleGroceryListServlet extends HttpServlet {
	private static GroceryList groceryList = null;

	public void init(ServletConfig config) throws ServletException { 
		super.init(config);
		String filename = config.getInitParameter("listfile");
		if (filename == null || filename.length() == 0) {
			throw new ServletException();
		}
		InputStream is = this.getClass().getClassLoader().getResourceAsStream(filename);
		try {
			groceryList = GroceryList.getInstance(is, filename);
		} catch (IOException exc) {
			exc.printStackTrace();
			throw new ServletException(exc);
		}
	}

	private String getPathParameter(HttpServletRequest req) throws Exception{
		String servletPath = req.getServletPath();

		String requestedURI = req.getRequestURI();

		String pathParameter = requestedURI.substring(requestedURI.indexOf(servletPath) + servletPath.length() + 1);
		boolean hasSlash = -1 != pathParameter.indexOf("/");
		if(pathParameter.length() == 0){
			throw new Exception("Invalid path paramater length");
		}
		else if(hasSlash){
			throw new Exception("Invalid path parameter /");
		}
		return pathParameter;

	}

	private void getParameters(HttpServletRequest req, String pathParameter, Vector<String> namesVector, Vector<String> brandsVector, Vector<Integer> aislesVector,
		Vector<Integer> quantitiesVector, Vector<String> customsVector) throws Exception{
		String names[] = pathParameter.split("-and-");
		for(int i = 0; i < names.length; i++){
			names[i] = URLDecoder.decode(names[i], "UTF-8");
		}

		CopyOnWriteArraySet namesSet = new CopyOnWriteArraySet();
		for(int i = 0; i < names.length; i++){
			namesSet.add(names[i]);
			namesVector.add(names[i]);
		}
		if (namesSet.size() != names.length){
			throw new Exception("Trying add or update multiple groceries with the same name");
		}

		if (req.getParameter("brands") == null || req.getParameter("aisles") == null || req.getParameter("quantities") == null
			|| req.getParameter("customs") == null){
			throw new Exception("Invalid parameter name");
		}

		String brandsString = req.getParameter("brands");
		String brands[] = brandsString.split("-and-");

		String aislesString = req.getParameter("aisles");
		String aisles[] = aislesString.split("-and-");

		String quantitiesString = req.getParameter("quantities");
		String quantities[] = quantitiesString.split("-and-");

		String customsString = req.getParameter("customs");
		String customs[] = customsString.split("-and-");
		


		if(names.length != brands.length || names.length != aisles.length || names.length != quantities.length 
			|| names.length != customs.length){
			throw new Exception("Number of names doesn't match the number of brands or aisles or quantities or customs");
		}

		for(int i = 0; i < names.length; i++){
			if(!brands[i].equals("NULL")){
				brandsVector.add(brands[i]);
			}
			else{
				brandsVector.add(null);
			}	
		}

		try{
			for(int i = 0; i < names.length; i++){
				if(!aisles[i].equals("NULL")){
					if (Integer.valueOf(aisles[i]) <= 0){
						throw new Exception("Aisle must be positive integer");
					}
					aislesVector.add(Integer.valueOf(aisles[i]));
				}
				else{
					aislesVector.add(null);
				}
			}
		}
		catch(Exception e){
			throw new Exception("aisles parameter contains a non positive integer");
		}

		try{
			for(int i = 0; i < names.length; i++){
				if (Integer.valueOf(quantities[i]) <= 0){
					throw new Exception("quantity must be positive integer");
				}
				quantitiesVector.add(Integer.valueOf(quantities[i]));
			}	
		}
		catch(Exception e){
			throw new Exception("quantities parameter contains a non positive integer");
		}

		for(int i = 0; i < customs.length; i++){
			customsVector.add(customs[i]);
		}

	}

	public void doPut(HttpServletRequest req, HttpServletResponse res) 
		throws ServletException, IOException{
		res.setContentType("application/json");
		PrintWriter out= res.getWriter();

		try {
			Vector<String> namesVector = new Vector<String>(); 
			Vector<String> brandsVector = new Vector<String>();
			Vector<Integer> aislesVector = new Vector<Integer>();
			Vector<Integer> quantitiesVector = new Vector<Integer>();
			Vector<String> customsVector = new Vector<String>();

			String pathParameter = this.getPathParameter(req);
			
			try{
				getParameters(req, pathParameter, namesVector, brandsVector, aislesVector, quantitiesVector, customsVector);
			}
			catch(Exception e){
				throw e;
			}

			if(!groceryList.hasEntryWithNames(namesVector)){
				throw new Exception("Grocery name doesn't exist");
			}

			for(int i = 0; i < namesVector.size(); i++){
				out.println(namesVector.get(i) + ":" + brandsVector.get(i)+ ":" +quantitiesVector.get(i) + ":" + aislesVector.get(i) + ":" + customsVector.get(i));
				groceryList.editEntry(namesVector.get(i),
					brandsVector.get(i), quantitiesVector.get(i),
					aislesVector.get(i), customsVector.get(i));
			}
			
			res.setStatus(res.SC_OK);		
		}
		catch (Exception exc){
			res.setStatus(res.SC_BAD_REQUEST);
			//out.println(exc.getMessage());
			//exc.printStackTrace();
		}
		finally{
			out.close();
		}
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) 
		throws ServletException, IOException{

		res.setContentType("application/json");
		PrintWriter out= res.getWriter();

		try {
			Vector<String> namesVector = new Vector<String>(); 
			Vector<String> brandsVector = new Vector<String>();
			Vector<Integer> aislesVector = new Vector<Integer>();
			Vector<Integer> quantitiesVector = new Vector<Integer>();
			Vector<String> customsVector = new Vector<String>();

			String pathParameter = this.getPathParameter(req);
			try{
				getParameters(req, pathParameter, namesVector, brandsVector, aislesVector, quantitiesVector, customsVector);
			}
			catch(Exception e){
				//res.setStatus(res.SC_BAD_REQUEST);
				throw e;
			}	

			if(groceryList.hasEntryWithNames(namesVector)){
				//res.setStatus(res.SC_BAD_REQUEST);
				throw new Exception("Grocery name already exist");
			}

			for(int i = 0; i < namesVector.size(); i++){
				//out.println(namesVector.get(i) + ":" + brandsVector.get(i)+ ":" +quantitiesVector.get(i) + ":" + aislesVector.get(i) + ":" + customsVector.get(i));
				GroceryEntry gEntry = new GroceryEntry(namesVector.get(i),
					brandsVector.get(i), quantitiesVector.get(i),
					aislesVector.get(i), customsVector.get(i));
				groceryList.addEntry(namesVector.get(i), gEntry);
			}
			res.setStatus(res.SC_CREATED);
			//out.println(res.getStatus());
		}
		catch (Exception exc){
			res.setStatus(res.SC_BAD_REQUEST);
			//out.println("Error!");
			//out.println(exc.getMessage());
		}
		finally{
			out.close();
		}
	}

	public void doDelete(HttpServletRequest req, HttpServletResponse res) 
		throws ServletException, IOException	{
		res.setContentType("application/json");
		PrintWriter out= res.getWriter();
		try {
			Vector<String> namesVector = new Vector<String>();
			String pathParameter = this.getPathParameter(req);
			String names[] = pathParameter.split("-and-");
			for(int i = 0; i < names.length; i++){
				names[i] = URLDecoder.decode(names[i], "UTF-8");
			}

			CopyOnWriteArraySet namesSet = new CopyOnWriteArraySet();
			for(int i = 0; i < names.length; i++){
				namesSet.add(names[i]);
				namesVector.add(names[i]);
			}
			if (namesSet.size() != names.length){
				throw new Exception("Trying delete multiple groceries with the same name");
			}
			if(!groceryList.hasEntryWithNames(namesVector)){
				throw new Exception("Grocery name doesn't exist");
			}
			for(int i = 0; i < namesVector.size(); i++){
				groceryList.deleteEntry(namesVector.get(i));
			}
			res.setStatus(res.SC_OK);
		}
		catch (Exception exc){
			res.setStatus(res.SC_BAD_REQUEST);
			//out.println(exc.getMessage());
			//exc.printStackTrace();
		}
		finally{
			out.close();
		}
	}

	public void doGet(HttpServletRequest req, HttpServletResponse res) 
		throws ServletException, IOException{
		res.setContentType("application/json");
		PrintWriter out= res.getWriter();
		try{
			String name = null;
			try{
				name = this.getPathParameter(req);
			}
			catch(Exception e){
				if(e.getMessage().equals("Invalid path parameter /")){
					throw e;
				}
			}
			String queryString = req.getQueryString();
			boolean isAisleQuery = false;
			boolean isCustomQuery = false;
			boolean isAisleAndCustomQuery = false;
			boolean isNoParametersQuery = false;
			String products[] = new String[0];
			Hashtable<String, String> queriesTable = new Hashtable<String, String>();
			if (queryString == null){
				isNoParametersQuery = true;
			}
			else{
				String queries[] = queryString.split("&");
				for(int i = 0; i < queries.length; i++){
					String query[] = queries[i].split("=");
					queriesTable.put(query[0], query[1]);
				}
				isAisleQuery = queriesTable.containsKey("aisle");
				isCustomQuery = queriesTable.containsKey("custom");
				isAisleAndCustomQuery = isAisleQuery && isCustomQuery;
				isNoParametersQuery = !isAisleQuery || !isCustomQuery;
			}
			if(isAisleAndCustomQuery){
				int aisleNumber = Integer.parseInt(queriesTable.get("aisle"));
				String custom = queriesTable.get("custom");
				custom = URLDecoder.decode(custom, "UTF-8");
				products = groceryList.nameWithAisleNumberAndCustom(aisleNumber, custom);
			}
			else if(isAisleQuery){
				int aisleNumber = Integer.parseInt(queriesTable.get("aisle"));
				products = groceryList.nameWithAisleNumber(aisleNumber);

			}	
			else if(isCustomQuery){
				String custom = queriesTable.get("custom");
				custom = URLDecoder.decode(custom, "UTF-8");
				products = groceryList.nameWithCustom(custom);
			}
			else if(isNoParametersQuery){
				products = groceryList.getNames();
			}
			else{
				throw new Exception("Unknown parameters");
			}

			if (name != null){
				StringBuilder sb = new StringBuilder();
				for (int i = 0; i < products.length; i++){
					if (products[i].equals(name)){
						sb.append("-and-" + products[i]);
					}
				}
				products = sb.toString().split("-and-");
			}

			if (products.length == 0){
				res.setStatus(res.SC_NO_CONTENT);
			}
			else{
				res.setStatus(res.SC_OK);
				JsonArrayBuilder builder = Json.createArrayBuilder();
				for(int i = 0; i < products.length; i++){
					if(name==null){
						builder.add(groceryList.getEntryJsonObject(products[i]));
					}
					else{
						if(products[i].equals(name)){
							builder.add(groceryList.getEntryJsonObject(products[i]));
						}
					}
				}
				JsonArray value = builder.build();
				out.println(value.toString());
			}
		}
		catch (Exception exc){
			res.setStatus(res.SC_BAD_REQUEST);
			//out.println(exc.getMessage());
			//res.setStatus(res.SC_BAD_REQUEST);
		}
		finally{
			out.close();
		}
	}
}
