package task1;
import javax.json.*;

public class GroceryEntry {
    public String name;
    public String brand; //optional
    public int quantity;
    public Integer aisle; //optional
    public String custom;

    public GroceryEntry(String name, String brand, int quantity, Integer aisle, String custom) throws Exception{
        this.name  = name;
        this.brand  = brand;
        this.quantity = quantity;
        this.aisle = aisle;
        this.custom = custom;
    }

    public void change(String brand, int quantity, Integer aisle, String custom) {
        this.brand  = brand;
        this.quantity = quantity;
        this.aisle = aisle;
        this.custom = custom;

    }

    public String toString(){ 
        return name + "\n" + brand + "\n" + quantity + "\n" + aisle + "\n" + custom + "\n"; 
    }

    public String toJson(){
        return toJsonObject().toString();
    }

    public GroceryEntry(JsonObject obj){
        this.name = obj.getString("name");
        try{
            this.brand = obj.getString("brand");
        }
        catch(Exception exp){
            this.brand = null;
        }
        this.quantity = obj.getInt("quantity");
        try{
            this.aisle = obj.getInt("aisle");
        }
        catch(Exception exp){
            this.aisle = null;
        }
        this.custom = obj.getString("custom");
    }

    public JsonObject toJsonObject(){
        JsonObjectBuilder builder = Json.createObjectBuilder()
        .add("name", name);
        if (brand != null){
            builder.add("brand", brand);
        }
        builder.add("quantity", quantity);
        if (aisle != null){
            builder.add("aisle", aisle);
        }
        builder.add("custom", custom);
        JsonObject value = builder.build();
        return value;
    }
}



