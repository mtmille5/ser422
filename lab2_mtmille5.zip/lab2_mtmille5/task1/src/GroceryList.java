package task1;

import java.io.*;
import java.util.*;
import java.util.Hashtable;
import java.util.Vector;
import javax.json.*;
import java.net.URL;

public class GroceryList {

	private Hashtable<String, GroceryEntry> groceryList = null;
	private static GroceryList singleton = null;
	private String fileName = null;

	private GroceryList(JsonArray array, String fileName){
		this.fileName = fileName;
		groceryList = new Hashtable<String, GroceryEntry>();
		for (int i = 0; i < array.size(); i++){
			GroceryEntry gEntry = new GroceryEntry(array.getJsonObject(i));
			groceryList.put(gEntry.name, gEntry);
		}
	}

	public static GroceryList getInstance(InputStream is, String fileName) throws IOException{
		if (singleton == null){
			JsonReader jsonReader = Json.createReader(is);
 			JsonArray array = jsonReader.readArray();
			singleton = new GroceryList(array, fileName);
			jsonReader.close();
		}
		return singleton;
	}

	public void editEntry(String name, String brand, int quantity, Integer aisle, String custom) throws Exception{
		GroceryEntry pentry = groceryList.get(name);
		pentry.change(brand, quantity, aisle, custom);
		singleton.save();
	}
	
	public void addEntry(String name, GroceryEntry gEntry) throws Exception{ 
		groceryList.put(name, gEntry);
		singleton.save();
	}

	public JsonObject getEntryJsonObject(String name) throws Exception{ 
		return groceryList.get(name).toJsonObject();
	}	

	public void deleteEntry(String name) throws Exception{
		groceryList.remove(name);
		singleton.save();
	}

	public boolean hasEntryWithName(String name){
		return groceryList.get(name) != null;
	}

	public boolean hasEntryWithNames(Vector<String> names){
		for(int i = 0; i < names.size(); i++){
			if(this.hasEntryWithName(names.get(i))){
				return true;
			}
		}
		return false;
	}

	public int getProductCount(){
		return groceryList.size();
	}

	public String[] nameWithAisleNumber(int aisleNumber){
		Enumeration<String> keys = groceryList.keys();
		Vector<String> products = new Vector<String>();
		while(keys.hasMoreElements()){
			String key = keys.nextElement();
			GroceryEntry gEntry = groceryList.get(key);
			if(gEntry.aisle == null){
				continue;
			}
			if(gEntry.aisle == aisleNumber){
				products.add(gEntry.name);
			}
		}
		String productsArray[] = new String[products.size()];
		return products.toArray(productsArray);
	}

	public String[] nameWithCustom(String custom){
		Enumeration<String> keys = groceryList.keys();
		Vector<String> products = new Vector<String>();
		while(keys.hasMoreElements()){
			String key = keys.nextElement();
			GroceryEntry gEntry = groceryList.get(key);
			if(gEntry.custom == null){
				continue;
			}
			if(gEntry.custom.contains(custom)){
				products.add(gEntry.name);
			}
		}
		String productsArray[] = new String[products.size()];
		return products.toArray(productsArray);
	}

	public String[] nameWithAisleNumberAndCustom(Integer aisleNumber, String custom){
		Enumeration<String> keys = groceryList.keys();
		Vector<String> products = new Vector<String>();
		while(keys.hasMoreElements()){
			String key = keys.nextElement();
			GroceryEntry gEntry = groceryList.get(key);
			if(gEntry.custom == null || gEntry.aisle == null){
				continue;
			}
			if(gEntry.aisle == aisleNumber && gEntry.custom.contains(custom)){
				products.add(gEntry.name);
			}
		}
		String productsArray[] = new String[products.size()];
		return products.toArray(productsArray);
	}

	public String[] getNames(){
		Enumeration<String> keys = groceryList.keys();
		Vector<String> products = new Vector<String>();
		while(keys.hasMoreElements()){
			String key = keys.nextElement();
			GroceryEntry gEntry = groceryList.get(key);
			products.add(gEntry.name);
		}
		String productsArray[] = new String[products.size()];
		return products.toArray(productsArray);
	}

	public JsonArray toJsonArray(){
		JsonArrayBuilder builder = Json.createArrayBuilder();
		Enumeration<String> keys = groceryList.keys();
		Vector<String> products = new Vector<String>();
		while(keys.hasMoreElements()){
			String key = keys.nextElement();
			GroceryEntry gEntry = groceryList.get(key);
			builder.add(gEntry.toJsonObject());
		}
		JsonArray value = builder.build();
		return value;
	}

	public String toJson(){
		return this.toJsonArray().toString();
	}

	public void save() throws Exception{
		if (fileName == null || fileName.length() == 0) {
	    	throw new Exception();
		}
		URL url = this.getClass().getClassLoader().getResource(fileName);
		File file = new File(url.toURI());
		FileOutputStream fos = new FileOutputStream(file);
 		JsonArray array = this.toJsonArray();
 		fos.write(array.toString().getBytes("UTF-8"));
 		fos.close();
	}
}
