#!/bin/bash
echo "sleep 10"
sleep 10
printf "\n\n\n\n\n\n"

echo "export website_path='http://localhost:8080'"
export website_path="http://localhost:8080"
printf "\n\n\n\n\n\n"

#Create
echo "---------------------CREATE-----------------------"
echo "Test 1"
echo "curl ${website_path}'/task1_mtmille5/groceries/apple' \
-iH 'Accept: application/json' \
--data-raw 'brands=the+apple+brand&quantities=5&aisles=NULL&customs=organic'"
curl ${website_path}'/task1_mtmille5/groceries/apple' \
-iH 'Accept: application/json' \
--data-raw 'brands=the+apple+brand&quantities=5&aisles=NULL&customs=organic'
printf "\n\n\n\n\n\n"

echo "Test 2"
echo "curl ${website_path}'/task1_mtmille5/groceries/pear-and-grape' \
-iH 'Accept: application/json' \
--data-raw 'brands=the+apple+brand-and-NULL&quantities=5-and-3&aisles=NULL-and-NULL&customs=orgainic-and-orgainic+sale'"
curl ${website_path}'/task1_mtmille5/groceries/pear-and-grape' \
-iH 'Accept: application/json' \
--data-raw 'brands=the+apple+brand-and-NULL&quantities=5-and-3&aisles=NULL-and-NULL&customs=orgainic-and-orgainic+sale'
printf "\n\n\n\n\n\n"

echo "Test 3"
echo "curl ${website_path}'/task1_mtmille5/groceries/milk' \
-iH 'Accept: application/json' \
--data-raw 'brands=lucerne&quantities=1&aisles=1&customs=1%25'"
curl ${website_path}'/task1_mtmille5/groceries/milk' \
-iH 'Accept: application/json' \
--data-raw 'brands=lucerne&quantities=1&aisles=1&customs=1%25'
printf "\n\n\n\n\n\n"

echo "Test 4"
echo "curl ${website_path}'/task1_mtmille5/groceries/milk/man' \
-iH 'Accept: application/json' \
--data-raw 'brands=lucerne&quantities=1&aisles=1&customs=1%25'"
curl ${website_path}'/task1_mtmille5/groceries/milk/man' \
-iH 'Accept: application/json' \
--data-raw 'brands=lucerne&quantities=1&aisles=1&customs=1%25'
printf "\n\n\n\n\n\n"


#Update
echo "---------------------UPDATE-----------------------"
echo "Test 1"
echo "curl -X PUT ${website_path}'/task1_mtmille5/groceries/apple?brands=the+apple+brand&quantities=5&aisles=NULL&customs=organic' \
-iH 'Accept: application/json'"
curl -X PUT ${website_path}'/task1_mtmille5/groceries/apple?brands=the+apple+brand&quantities=5&aisles=NULL&customs=organic' \
-iH 'Accept: application/json'
printf "\n\n\n\n\n\n"

echo "Test 2"
echo "curl -X PUT ${website_path}'/task1_mtmille5/groceries/pear?brands=NULL&quantities=3&aisles=NULL&customs=organic+sale' \
-iH 'Accept: application/json'"
curl -X PUT ${website_path}'/task1_mtmille5/groceries/pear?brands=NULL&quantities=3&aisles=NULL&customs=organic+sale' \
-iH 'Accept: application/json'
printf "\n\n\n\n\n\n"

echo "Test 3"
echo "curl -X PUT ${website_path}'/task1_mtmille5/groceries/milkyway?brands=lucerne&quantities=1&aisles=1&customs=1%25' \
-iH 'Accept: application/json'"
curl -X PUT ${website_path}'/task1_mtmille5/groceries/milkyway?brands=lucerne&quantities=1&aisles=1&customs=1%25' \
-iH 'Accept: application/json'
printf "\n\n\n\n\n\n"

echo "Test 4"
echo "curl -X PUT ${website_path}'/task1_mtmille5/groceries/apple?brands=&quantities=0&aisles=1&customs=1%25' \
-iH 'Accept: application/json'"
curl -X PUT ${website_path}'/task1_mtmille5/groceries/apple?brands=&quantities=0&aisles=1&customs=1%25' \
-iH 'Accept: application/json'
printf "\n\n\n\n\n\n"

#Delete
echo "---------------------DELETE-----------------------"
echo "Test 1"
echo "curl -X DELETE ${website_path}'/task1_mtmille5/groceries/apple' \
-iH 'Accept: application/json' "
curl -X DELETE ${website_path}'/task1_mtmille5/groceries/apple' \
-iH 'Accept: application/json' 
printf "\n\n\n\n\n\n"

# Delete pear
echo "Test 2"
echo "curl -X DELETE ${website_path}'/task1_mtmille5/groceries/pear' \
-iH 'Accept: application/json'"
curl -X DELETE ${website_path}'/task1_mtmille5/groceries/pear' \
-iH 'Accept: application/json'
printf "\n\n\n\n\n\n"

# Delete milkway
echo "Test 3"
echo "curl -X DELETE ${website_path}'/task1_mtmille5/groceries/milkyway' \
-iH 'Accept: application/json'"
curl -X DELETE ${website_path}'/task1_mtmille5/groceries/milkyway' \
-iH 'Accept: application/json'
printf "\n\n\n\n\n\n"

# Delete m/i/l/k
echo "Test 4"
echo "curl -X DELETE ${website_path}'/task1_mtmille5/groceries/m/i/l/k' \
-iH 'Accept: application/json'"
curl -X DELETE ${website_path}'/task1_mtmille5/groceries/m/i/l/k' \
-iH 'Accept: application/json'
printf "\n\n\n\n\n\n"

#Retrieve
echo "---------------------RETRIEVE-----------------------"
echo "Test 1"
echo "curl ${website_path}'/task1_mtmille5/groceries?aisle=5' \
-iH 'Accept: application/json'"
curl ${website_path}'/task1_mtmille5/groceries?aisle=5' \
-iH 'Accept: application/json'
printf "\n\n\n\n\n\n"

echo "Test 2"
echo "curl ${website_path}'/task1_mtmille5/groceries?custom=organic' \
-iH 'Accept: application/json'"
curl ${website_path}'/task1_mtmille5/groceries?custom=organic' \
-iH 'Accept: application/json'
printf "\n\n\n\n\n\n"

echo "Test 3"
echo "curl ${website_path}'/task1_mtmille5/groceries/milkway' \
-iH 'Accept: application/json'"
curl ${website_path}'/task1_mtmille5/groceries/milkway' \
-iH 'Accept: application/json'
printf "\n\n\n\n\n\n"

echo "Test 4"
echo "curl ${website_path}'/task1_mtmille5/groceries?aisle=99custom=organic' \
-iH 'Accept: application/json'"
curl ${website_path}'/task1_mtmille5/groceries?aisle=99custom=organic' \
-iH 'Accept: application/json'
printf "\n\n\n\n\n\n"



