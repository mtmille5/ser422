From the project root directory do the following steps to start docker container to run and test the grocery list application.
1. Run "ant deploy" in the ./task1 folder
2. Change back into the root directory with the Dockerfile "cd .."
2. "docker build -t tmillermillert/lab2_mtmille5:1 ."
3. "docker run -itd \
--publish 8001:8080 --rm \
tmillermillert/lab2_mtmille5:1"
